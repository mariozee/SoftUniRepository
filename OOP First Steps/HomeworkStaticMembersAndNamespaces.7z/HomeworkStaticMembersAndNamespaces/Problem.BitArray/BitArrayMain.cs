﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem.BitArray
{
    class BitArrayMain
    {
        static void Main()
        {
            BitArray a = new BitArray(23, 34, 54, 65, 34, 56, 345, 32, 23, 34, 34545, 34, 34);

            
        }
    }
}
