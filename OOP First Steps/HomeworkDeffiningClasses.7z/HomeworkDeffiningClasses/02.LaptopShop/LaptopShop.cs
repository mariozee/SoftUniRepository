﻿using System;

class LaptopShop
{
    static void Main()
    {
        Laptop n = new Laptop("asd", 5);    
    }
}

