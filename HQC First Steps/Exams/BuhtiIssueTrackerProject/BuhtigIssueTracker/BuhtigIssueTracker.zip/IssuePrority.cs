﻿namespace BuhtigIssueTracker
{
    public enum IssuePrority
    {
        Showstopper = 4,
        High = 3,
        Medium = 2,
        Low = 1
    }
}