﻿namespace LearningSystem.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
