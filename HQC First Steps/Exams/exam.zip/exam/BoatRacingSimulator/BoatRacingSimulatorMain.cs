﻿namespace BoatRacingSimulator
{
    using Core;

    public class BoatRacingSimulatorMain
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
