﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoatRacingSimulator.Interfaces
{
    public interface IBoat : IModelable
    { 
        string Model { get; }       

        int Weight { get; }       

        double CalculateRaceSpeed(IRace race);
    }
}
