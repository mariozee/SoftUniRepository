﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BoatRacingSimulator.Interfaces;
using BoatRacingSimulator.Utility;

namespace BoatRacingSimulator.Models
{
    public class Yacht : Boat
    {
        private int cargoWeight;

        public Yacht(string model, int weight, IEngine engine, int cargoWeight)
            : base(model, weight)
        {
        }

        public IEngine Engine { get; private set; }

        public int CargoWeight
        {
            get
            {
                return this.cargoWeight;
            }

            private set
            {
                Validator.ValidatePropertyValue(value, "Cargo Weight");
                this.cargoWeight = value;
            }
        }

        public override double CalculateRaceSpeed(IRace race)
        {
            var speed = this.Engine.Output - this.Weight + this.CargoWeight + (race.OceanCurrentSpeed / 2d);

            return speed;
        }
    }
}
