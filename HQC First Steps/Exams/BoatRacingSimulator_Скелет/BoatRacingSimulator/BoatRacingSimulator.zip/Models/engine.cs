﻿namespace BoatRacingSimulator.Models
{
    using System;
    using BoatRacingSimulator.Interfaces;
    using BoatRacingSimulator.Utility;

    public abstract class Engine : IEngine
    {
        private string model;
        private int horsepower;
        private int displacement;

        public Engine(string model, int horsepower, int displacement)
        {
            this.Model = model;
            this.Horsepower = horsepower;
            this.Displacement = displacement;
        }

        public string Model
        {
            get
            {
                return this.model;
            }

            private set
            {
                Validator.ValidateModelLength(value, Constants.MinBoatEngineModelLength);
                this.model = value;
            }
        }


        public int CachedOutput { get; set; }

        public int Horsepower
        {
            get
            {
                return this.horsepower;
            }

            set
            {
                Validator.ValidatePropertyValue(value, "Horsepower");
                this.horsepower = value;
            }
        }

        public int Displacement
        {
            get
            {
                return this.displacement;
            }

            set
            {
                Validator.ValidatePropertyValue(value, "Displacement");
                this.displacement = value;
            }
        }

        public abstract int Output { get; }
    }

    //class JetEngine : Engine, IModelable
    //{
    //    private const int Multiplier = 5;

        //private string model;

        //private int horsepower;

        //private int displacement;

        //public JetEngine(string model, int horsepower, int displacement)
        //{
        //    this.Model = model;
        //    this.Horsepower = horsepower;
        //    this.Displacement = displacement;
        //}

        //public string Model
        //{
        //    get
        //    {
        //        return this.model;
        //    }

        //    private set
        //    {
        //        Validator.ValidateModelLength(value, Constants.MinBoatEngineModelLength);
        //        this.model = value;
        //    }
        //}

        //public override int Output
        //{
        //    get
        //    {
        //        if (this.CachedOutput != 0)
        //        {
        //            return this.CachedOutput;
        //        }

        //        this.CachedOutput = (this.Horsepower * Multiplier) + this.Displacement;
        //        return this.CachedOutput;
        //    }
        //}

        //protected int CachedOutput { get; set; }

        //protected int Horsepower
        //{
        //    get
        //    {
        //        return this.horsepower;
        //    }

        //    set
        //    {
        //        Validator.ValidatePropertyValue(value, "Horsepower");
        //        this.horsepower = value;
        //    }
        //}

    }

//    class SterndriveEngine : Engine, IModelable
//    {
//        private const int Multiplier = 7;

//        private string model;

//        private int horsepower;

//        private int displacement;

//        public SterndriveEngine(string model, int horsepower, int displacement)
//        {
//            this.Model = model;
//            this.Horsepower = horsepower;
//            this.Displacement = displacement;
//        }

//        public string Model
//        {
//            get
//            {
//                return this.model;
//            }

//            private set
//            {
//                Validator.ValidateModelLength(value, Constants.MinBoatEngineModelLength);
//                this.model = value;
//            }
//        }

//        public override int Output
//        {
//            get
//            {
//                if (this.CachedOutput != 0)
//                {
//                    return this.CachedOutput;
//                }

//                this.CachedOutput = (this.Horsepower * Multiplier) + this.Displacement;
//                return this.CachedOutput;
//            }
//        }

//        protected int CachedOutput { get; set; }

//        protected int Horsepower
//        {
//            get
//            {
//                return this.horsepower;
//            }

//            set
//            {
//                Validator.ValidatePropertyValue(value, "Horsepower");
//                this.horsepower = value;
//            }
//        }

//        protected int Displacement
//        {
//            get
//            {
//                return this.displacement;
//            }

//            set
//            {
//                Validator.ValidatePropertyValue(value, "Displacement");
//                this.displacement = value;
//            }
//        }
//    }
//}
