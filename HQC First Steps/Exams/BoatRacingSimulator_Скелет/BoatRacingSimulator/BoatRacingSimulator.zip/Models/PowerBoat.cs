﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BoatRacingSimulator.Interfaces;

namespace BoatRacingSimulator.Models
{
    public class PowerBoat : Boat
    {
        public PowerBoat(string model, int weight, IEngine firstEngine, IEngine secondEngine, bool isSailBoat)
            : base(model, weight)
        {
            this.FirstEngine = firstEngine;
            this.SecondEngine = secondEngine;
            this.IsSailBoat = isSailBoat;
        }

        public IEngine FirstEngine { get; private set; }

        public IEngine SecondEngine { get; private set; }

        public bool IsSailBoat { get; private set; }

        public override double CalculateRaceSpeed(IRace race)
        {
            var speed = this.FirstEngine.Output + this.SecondEngine.Output - this.Weight + (race.OceanCurrentSpeed / 5d);
            return speed;
        }
    }
}
