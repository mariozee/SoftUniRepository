package com.company;

import javafx.scene.control.SplitPane;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int a = 254;
        //int aHex = 0x254;
        String hexa = Integer.toHexString(a);
        System.out.println(hexa.toUpperCase());
    }
}
