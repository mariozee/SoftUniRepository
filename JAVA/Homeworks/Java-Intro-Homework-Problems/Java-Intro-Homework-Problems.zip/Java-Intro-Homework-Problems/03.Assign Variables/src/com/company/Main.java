package com.company;

import java.math.BigDecimal;

public class Main {

    public static void main(String[] args) {

        byte byteVar = 123;
        short shortVar = 1569;
        int intVar = 1456000;
        long longVar = 30000000L;
        char charVar = 'F';
        boolean boolVar = true;
        float floatVar = 3.3343F;
        double doubleVar = 35.2344534;
    }
}
