package com.company;

public class Main {

    public static void main(String[] args) {
        for (char c = 'a'; c <= 'z'; c++){
            System.out.print(c + " ");
        }
    }
}
