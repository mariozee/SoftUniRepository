﻿namespace WinterIsComing.Enums
{
    public enum UnitType
    {
        Mage,
        Warrior,
        IceGiant
    }
}
