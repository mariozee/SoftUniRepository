﻿using System;
using System.Runtime.Serialization;

namespace WinterIsComing.Core.Commands
{
    [Serializable]
    internal class GameExcepetion : Exception
    {
        public GameExcepetion()
        {
        }

        public GameExcepetion(string message) : base(message)
        {
        }

        public GameExcepetion(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected GameExcepetion(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}