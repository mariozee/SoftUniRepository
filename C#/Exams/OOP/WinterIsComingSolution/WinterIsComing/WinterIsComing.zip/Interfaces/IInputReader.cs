﻿namespace WinterIsComing.Interfaces
{
    public interface IInputReader
    {
        string ReadLine();
    }
}
