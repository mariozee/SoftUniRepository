﻿namespace WinterIsComing.Interfaces
{
    public interface ISpell
    {
        int Damage { get; }

        int EnergyCost { get; }
    }
}
