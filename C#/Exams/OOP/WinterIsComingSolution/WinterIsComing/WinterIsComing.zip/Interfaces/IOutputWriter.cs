﻿namespace WinterIsComing.Interfaces
{
    public interface IOutputWriter
    {
        void WriteLine(string message);
    }
}
