﻿namespace KremenCity
{
    using System;

    public class Startup
    {
        static void Main()
        {
            KermenData data = new KermenData();
            Factory factory = new Factory();
            int commandsCounter = 0;

            string input = Console.ReadLine();
            
            while (true)
            {
                commandsCounter++;
                bool areSalariesPayd = false;

                try
                {
                    if (input == "EVN")
                    {
                        PrintTotalConsumption(data);
                    }
                    else if (input == "EVN bill")
                    {
                        if (commandsCounter % 3 == 0)
                        {
                            PaySalaries(data);
                            areSalariesPayd = true;
                        }

                        PayBills(data);
                    }
                    else if (input == "Democracy")
                    {
                        PrintTotalPopulation(data);
                        break;
                    }
                    else
                    {
                        var household = factory.CreateHousehold(input);
                        data.AddHousehold(household);
                    }

                    if (commandsCounter % 3 == 0 && !areSalariesPayd)
                    {
                        PaySalaries(data);
                    }
                }
                catch (ArgumentException)
                {
                    input = Console.ReadLine();
                    continue;
                }

                input = Console.ReadLine();
            }            
        }

        private static void PaySalaries(KermenData data)
        {
            data.PaySalaries();
        }

        private static void PrintTotalPopulation(KermenData data)
        {
            int population = data.GetPopulationCount();
            Console.WriteLine("Total population: {0}", population);
        }

        private static void PayBills(KermenData data)
        {
            data.PayBills();
        }

        private static void PrintTotalConsumption(KermenData data)
        {
            decimal consumption = data.GetTotalConsumption();
            Console.WriteLine("Total consumption: {0}", consumption);
        }
    }
}