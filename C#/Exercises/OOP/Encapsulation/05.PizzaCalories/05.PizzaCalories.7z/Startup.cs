﻿using _05.PizzaCalories.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.PizzaCalories
{
    public class Startup
    {
        public static void Main()
        {
            try
            {
                string line = Console.ReadLine();
                string pizzaName = line.Split()[1];
                int toppingCount = int.Parse(line.Split()[2]);
                var pizza = new Pizza(pizzaName, toppingCount);

                line = Console.ReadLine();
                string doughType = line.Split()[1];
                string bakingTechnique = line.Split()[2];
                double doughtWeight = double.Parse(line.Split()[3]);
                var dough = new Dough(doughType, bakingTechnique, doughtWeight);

                pizza.Dough = dough;

                for (int i = 0; i < toppingCount; i++)
                {
                    line = Console.ReadLine();
                    string toppingType = line.Split()[1];
                    double toppingWeight = double.Parse(line.Split()[2]);
                    var topping = new Topping(toppingType, toppingWeight);

                    pizza.AddToppin(topping);
                }

                Console.WriteLine("{0} - {1:F2} Calories", pizza.Name, pizza.Calories);
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
            }

           
        }
    }
}
